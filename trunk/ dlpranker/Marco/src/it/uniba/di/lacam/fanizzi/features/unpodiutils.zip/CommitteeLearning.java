package com.neuralnoise.committee.learning;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.neuralnoise.committee.Committee;
import com.neuralnoise.example.AbstractInstance;
import com.neuralnoise.feature.AbstractFeatureContent;
import com.neuralnoise.search.AbstractLearning;
import com.neuralnoise.search.AbstractModel;

public class CommitteeLearning<I extends AbstractInstance> extends AbstractLearning<I> {

	private static final Logger log = LoggerFactory.getLogger(CommitteeLearning.class);

	@Override
	public AbstractModel learn(int arity, Set<AbstractFeatureContent> contents,
			Set<I> positives, Set<I> negatives, Set<I> neutrals) throws Exception {
		return new Committee(arity, contents);
	}
}
