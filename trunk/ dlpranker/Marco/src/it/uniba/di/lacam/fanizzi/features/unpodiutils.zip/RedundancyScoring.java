package com.neuralnoise.committee.scoring;

import java.util.HashSet;
import java.util.Set;

import com.neuralnoise.committee.Committee;
import com.neuralnoise.example.AbstractInstance;
import com.neuralnoise.feature.AbstractFeatureContent;
import com.neuralnoise.inference.AbstractInference;
import com.neuralnoise.search.AbstractModel;
import com.neuralnoise.search.AbstractScoring;

public class RedundancyScoring<I extends AbstractInstance> extends AbstractScoring<I> {

	private AbstractInference inference;
	
	public RedundancyScoring(AbstractInference inference,
			Set<I> positives, Set<I> negatives, Set<I> neutrals) {
		super(positives, negatives, neutrals);
		this.inference = inference;
	}

	@Override
	public Double score(AbstractModel m) {
		if (!(m instanceof Committee)) {
			throw new IllegalStateException("The model should be an instance of Committee");
		}
		
		Committee c = (Committee) m;
		Set<AbstractFeatureContent> components = c.getComponents();
		
		Set<I> individuals = new HashSet<I>();
		if (positives != null)
			individuals.addAll(positives);
		if (negatives != null)
			individuals.addAll(negatives);
		if (neutrals != null)
			individuals.addAll(neutrals);
		
		double sS = components.size();
		
		InformationTheoryUtils<I> itu = new InformationTheoryUtils<I>(this.inference);
		double sum = 0.0;
		
		for (AbstractFeatureContent X : components) {
			for (AbstractFeatureContent Y : components) {
				sum += itu.I(X, Y, individuals);
			}
		}
		
		double ret = (sS > 0.0 ? sum / Math.pow(sS, 2) : Double.POSITIVE_INFINITY);
		return ret;
	}

}
