package com.neuralnoise.committee.scoring;

import java.util.Set;

import com.neuralnoise.example.AbstractInstance;
import com.neuralnoise.inference.AbstractInference;
import com.neuralnoise.search.AbstractModel;
import com.neuralnoise.search.AbstractScoring;

public class MEMRScoring<I extends AbstractInstance> extends AbstractScoring<I> {

	private AbstractInference inference;
	private double lambda;
	
	public MEMRScoring(AbstractInference inference, double lambda,
			Set<I> positives, Set<I> negatives, Set<I> neutrals) {
		super(positives, negatives, neutrals);
		this.inference = inference;
		this.lambda = lambda;
	}
	
	public MEMRScoring(AbstractInference inference,
			Set<I> positives, Set<I> negatives, Set<I> neutrals) {
		this(inference, 1.0, positives, negatives, neutrals);
	}
	
	@Override
	public Double score(AbstractModel m) {
		RedundancyScoring<I> red = new RedundancyScoring<I>(inference, positives, negatives, neutrals);
		EntropyScoring<I> ent = new EntropyScoring<I>(inference, positives, negatives, neutrals);
		
		Double ret = ent.score(m) - (lambda * red.score(m));
		return ret;
	}
}
