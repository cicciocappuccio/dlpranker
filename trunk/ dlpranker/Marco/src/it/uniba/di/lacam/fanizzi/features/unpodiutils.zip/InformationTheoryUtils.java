package com.neuralnoise.committee.scoring;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Sets;
import com.google.common.collect.Table;
import com.google.common.collect.Table.Cell;
import com.neuralnoise.example.AbstractInstance;
import com.neuralnoise.feature.AbstractFeatureContent;
import com.neuralnoise.inference.AbstractInference;
import com.neuralnoise.utils.Logic;
import com.neuralnoise.utils.Logic.Value;

public class InformationTheoryUtils<I extends AbstractInstance> {

	private AbstractInference inference;
	
	public InformationTheoryUtils(AbstractInference inference) {
		this.inference = inference;
	}
	
	
	public double E(AbstractFeatureContent X, Set<I> individuals) {
	
		Map<Value, Double> pX = new HashMap<Logic.Value, Double>();

		for (Value xi : X.getValues()) {
			pX.put(xi, 1.0);
		}
		
		Double ZX = 1.0;

		for (I individual : individuals) {
			Value Xcov = inference.cover(X, individual);
			if (Xcov != null) {
				pX.put(Xcov, pX.get(Xcov) + 1.0);
				ZX += 1.0;
			}
		}
		
		for (Entry<Value, Double> px : pX.entrySet()) {
			pX.put(px.getKey(), px.getValue() / ZX);
		}
		
		double ret = 0.0;
		
		for (Value xi : X.getValues()) {
			Double pxi = pX.get(xi);	
			ret -= (pxi * Math.log(pxi));
		}
		
		return ret;
	}
	
	
	public double I(AbstractFeatureContent X, Set<I> positives, Set<I> negatives) {
		Map<Value, Double> pX = new HashMap<Logic.Value, Double>();
		Map<Value, Double> pC = new HashMap<Logic.Value, Double>();
		Table<Value, Value, Double> pXC = HashBasedTable.create();
		
		for (Value xi : X.getValues()) {
			pX.put(xi, 1.0);
		}
		
		pC.put(Value.TRUE, 1.0);
		pC.put(Value.FALSE, 1.0);
		
		for (Value xi : pX.keySet()) {
			for (Value c : pC.keySet()) {
				pXC.put(xi, c, 1.0);
			}
		}
		
		Double ZX = 1.0;
		Double ZC = 1.0;
		Double ZXC = 1.0;

		Set<I> individuals = Sets.union(positives, negatives);
		
		for (I individual : individuals) {
			Value Xcov = inference.cover(X, individual);
			if (Xcov != null) {
				pX.put(Xcov, pX.get(Xcov) + 1.0);
				ZX += 1.0;
			}
			
			Value Ccov = (positives.contains(individual) ? Value.TRUE : Value.FALSE);
			if (Ccov != null) {
				pC.put(Ccov, pC.get(Ccov) + 1.0);
				ZC += 1.0;
			}
			
			if (Xcov != null && Ccov != null) {
				pXC.put(Xcov, Ccov, pXC.get(Xcov, Ccov) + 1.0);
			}
		}
		
		for (Entry<Value, Double> px : pX.entrySet()) {
			pX.put(px.getKey(), px.getValue() / ZX);
		}
		
		for (Entry<Value, Double> pc : pC.entrySet()) {
			pC.put(pc.getKey(), pc.getValue() / ZC);
		}
		
		for (Cell<Value, Value, Double> pxc : pXC.cellSet()) {
			pXC.put(pxc.getRowKey(), pxc.getColumnKey(), pxc.getValue() / ZXC);
		}
		
		double ret = 0.0;
		
		for (Value xi : X.getValues()) {
			for (Value c : pC.keySet()) {
				Double pxic = pXC.get(xi, c);
				Double pxi = pX.get(xi);
				Double pc = pC.get(c);
				ret += pxic * Math.log(pxic / (pxi * pc));
			}
		}
		
		return ret;
	}
	
	public double I(AbstractFeatureContent X, AbstractFeatureContent Y, Set<I> individuals) {
		
		Map<Value, Double> pX = new HashMap<Logic.Value, Double>();
		Map<Value, Double> pY = new HashMap<Logic.Value, Double>();
		Table<Value, Value, Double> pXY = HashBasedTable.create();
		
		for (Value xi : X.getValues()) {
			pX.put(xi, 1.0);
		}
		
		for (Value yj : Y.getValues()) {
			pY.put(yj, 1.0);
		}
		
		for (Value xi : X.getValues()) {
			for (Value yj : Y.getValues()) {
				pXY.put(xi, yj, 1.0);
			}
		}
		
		Double ZX = 1.0;
		Double ZY = 1.0;
		Double ZXY = 1.0;

		for (I individual : individuals) {
			Value Xcov = inference.cover(X, individual);
			if (Xcov != null) {
				pX.put(Xcov, pX.get(Xcov) + 1.0);
				ZX += 1.0;
			}
			
			Value Ycov = inference.cover(Y, individual);
			if (Ycov != null) {
				pY.put(Ycov, pY.get(Ycov) + 1.0);
				ZY += 1.0;
			}
			
			if (Xcov != null && Ycov != null) {
				pXY.put(Xcov, Ycov, pXY.get(Xcov, Ycov) + 1.0);
				ZXY += 1.0;
			}
		}
		
		for (Entry<Value, Double> px : pX.entrySet()) {
			pX.put(px.getKey(), px.getValue() / ZX);
		}
		
		for (Entry<Value, Double> py : pY.entrySet()) {
			pY.put(py.getKey(), py.getValue() / ZY);
		}
		
		for (Cell<Value, Value, Double> pxy : pXY.cellSet()) {
			pXY.put(pxy.getRowKey(), pxy.getColumnKey(), pxy.getValue() / ZXY);
		}
		
		double ret = 0.0;
		
		for (Value xi : X.getValues()) {
			for (Value yj : Y.getValues()) {
				Double pxiyj = pXY.get(xi, yj);
				Double pxi = pX.get(xi);
				Double pyj = pY.get(yj);
				ret += pxiyj * Math.log(pxiyj / (pxi * pyj));
			}
		}
		
		return ret;
	}
	
}
