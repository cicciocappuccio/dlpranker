#!/bin/bash

source func.sh

rm manifest.ttl
createManifest "Serialization"
