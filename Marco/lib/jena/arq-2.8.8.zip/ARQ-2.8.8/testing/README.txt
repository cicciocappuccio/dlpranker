Testing
=======

Test sets can be run with the arq.qtest command line tool
(a wrapper round JUnit).

In the ARQ system test suite:

ARQ/            Tests of the ARQ system
LARQ/           Test files for Lucene-ARQ
DAWG/           DAWG formal test suite

"DAWG" is "Data Access Working Group"
